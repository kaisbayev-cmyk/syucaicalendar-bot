from datetime import datetime
from descriptions import personal_year_descriptions, personal_day_descriptions, special_common_day_descriptions

def reduce_to_one_digit(n: int) -> int:
    while n > 9:
        n = sum(int(d) for d in str(n))
    return n

def calculate_common_day(date: datetime) -> (int, str):
    total = sum(int(d) for d in date.strftime("%d%m%Y"))
    reduced = reduce_to_one_digit(total)

    description = ""
    if reduced in [3, 6]:
        description = special_common_day_descriptions[reduced]
    elif date.day in [10, 20, 30]:
        description = special_common_day_descriptions["reset"]

    return reduced, description

def calculate_personal_year(birth_date: datetime, today: datetime) -> int:
    total = birth_date.day + birth_date.month + today.year
    return reduce_to_one_digit(total)

def calculate_personal_month(personal_year: int, month: int) -> int:
    return reduce_to_one_digit(personal_year + month)

def calculate_personal_day(personal_month: int, day: int) -> int:
    return reduce_to_one_digit(personal_month + day)

def generate_message(birth_date: datetime, today: datetime) -> str:
    common_day, common_desc = calculate_common_day(today)
    personal_year = calculate_personal_year(birth_date, today)
    personal_month = calculate_personal_month(personal_year, today.month)
    personal_day = calculate_personal_day(personal_month, today.day)

    msg = f"Сегодня Общий день: {common_day}."
    if common_desc:
        msg += f" {common_desc}"

    msg += f"\nЛичный год {personal_year}. {personal_year_descriptions[personal_year]}"
    msg += f"\nЛичный месяц {personal_month}."
    msg += f"\nЛичный день {personal_day}. {personal_day_descriptions[personal_day]}"
    return msg