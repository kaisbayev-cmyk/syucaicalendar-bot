import logging
from aiogram import Bot, Dispatcher, executor, types
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from numerology import generate_message
from datetime import datetime
import os

API_TOKEN = os.getenv("BOT_TOKEN")
logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

user_birthdays = {}  # user_id: datetime

@dp.message_handler(commands=['start'])
async def start_handler(message: types.Message):
    await message.reply("Привет! Отправь свою дату рождения в формате ДД.ММ.ГГГГ")

@dp.message_handler()
async def birthday_handler(message: types.Message):
    try:
        birth_date = datetime.strptime(message.text, "%d.%m.%Y")
        user_birthdays[message.from_user.id] = birth_date
        await message.reply("Дата рождения сохранена! Я буду присылать тебе ежедневные нумерологические подсказки.")
    except:
        await message.reply("Пожалуйста, отправь дату в формате ДД.ММ.ГГГГ")

async def send_daily_messages():
    today = datetime.now()
    for user_id, birth_date in user_birthdays.items():
        msg = generate_message(birth_date, today)
        try:
            await bot.send_message(user_id, msg)
        except Exception as e:
            print(f"Ошибка при отправке пользователю {user_id}: {e}")

if __name__ == "__main__":
    scheduler = AsyncIOScheduler()
    scheduler.add_job(send_daily_messages, "cron", hour=8, minute=0)
    scheduler.start()

    executor.start_polling(dp, skip_updates=True)